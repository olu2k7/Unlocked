<?php

session_start();
?>

<html>
<head>
<title> Home page </title>

</head>
<body>
Welcome

</body>

</html>